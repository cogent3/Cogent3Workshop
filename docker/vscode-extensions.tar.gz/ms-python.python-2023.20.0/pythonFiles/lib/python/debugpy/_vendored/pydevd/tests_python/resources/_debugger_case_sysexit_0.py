import sys


def main():
    print('TEST SUCEEDED!')
    sys.exit(0)


main()  # call_main_line
