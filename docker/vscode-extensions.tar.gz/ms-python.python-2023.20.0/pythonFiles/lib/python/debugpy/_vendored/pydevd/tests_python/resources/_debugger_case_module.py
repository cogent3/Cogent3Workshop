class MyVersion(object):
    pass


class MyPackage(object):
    pass


class MyName(object):
    pass


__version__ = MyVersion()
__package__ = MyPackage()
__name__ = MyName()

print('TEST SUCEEDED')  # Break here
