call = lambda b:(
        b,
        1,  # Break here
    )
call(1)
call(2)

print('TEST SUCEEDED')