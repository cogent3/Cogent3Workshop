class ClassToBeImported(object):
    pass