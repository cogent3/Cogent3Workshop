def foo():
    a=1
    b=2
    c=3
    d=4
    e=5
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    if a == 1:
        if b == 2:
            if c == 3:
                if d == 999:
                    x = 20
                elif d == 998:
                    x = 40
                elif d == 4:
                    if e != 5:
                        x = 20
                    else:
                        x = 50
    assert x